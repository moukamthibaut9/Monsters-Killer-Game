
			            < ================================================================================ >
			    	
                                                    	# MONSTERS - KILLER - GAME
                                                    		
				        < ================================================================================ >

						                             --------------------------------
						                            | ## Guide for program execution |
						                             --------------------------------

To run the game on your computer, open the game folder and execute the **linux_game** or **windows_game** file depending of your platform.  

							                             ---------------------
							                            | ## Game Description |
							                             ---------------------

    This game consists in a quest where the main character who is the player must eliminate monsters that are trying to kill him.  
    The game has three main stages and each stage ends when the final monster of this one is K.O  
    
                            							 ---------------------
							                            | ## Game Fonctioning |
							                             ---------------------
    							 
    When program is launched, the player player must enter an _username_(which he can always use for future connections if he wishes to continue at the stage where he stopped during his last connection); select an avatar and choose to _start_ or to _continue_ game.  
    When the game is launched, the player must do everything possible to keep his life bar above zero until he manages to eliminate the final boss monster of the stage.  
    To inflict damages to his enemies, the player can attack them with a sword by pressing the **SPACE KEY** on his keyboard or launch projectiles by simultaneously pressing **SPACE KEY** and **X KEY**.  
    To move player, use **direction keys** (alternatives: **A**,**W** and **D keys**)
    Sometimes, bonus can appear in the game surface, the player must take them to be immunised against monsters attacks or to increase his life bar.  
    
                            							   -------------------
							                              | ## Monsters Types |
							                               -------------------
    
* Simples monsters: Zombies that inflict minor damages to the player if they touch him
* Kamikazes birds: Birds that attack in the air and which explode by touching the player (inflicting him damages) or his projectiles
* Main monster: It's the final boss monster of a stage


    

