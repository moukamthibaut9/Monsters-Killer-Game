
			    	< ================================================================================ >
			    	
                                                    		# MONSTERS - KILLER - GAME
                                                    		
				< ================================================================================ >  



							 --------------------------------
							| ## Guide for program execution |
							 --------------------------------

1. To be able to run the game on your computer, first make sure to install at least version 3 of Python.
* [**clic here**](https://www.python.org) for download it on official site
* During installation, make sure to check the case _add to path_
2. Then, use the python package manager(**_pip_**) to install the pygame library(version 2.6.0 minimun)
* For it, open your _terminal_ or _command prompt_ and type:  
  _**pip install pygame==2.6.0**_ or _**pip3 install pygame==2.6.0**_(on linux OS)  
3. After all this, always in your _terminal_ or _command prompt_, use **cd** command to change your location and go in the game directory and type _pyhton main.py_ or _python3 main.py_ to launch game  



								 ---------------------
								| ## Game Description |
								 ---------------------

    This game consists in a quest where the main character who is the player must eliminate monsters that are triying to kill him.  
    The game has three main stages and each stage ends when the final monster of this one is K.O  
    
    
    
    								 ---------------------
								| ## Game Fonctioning |
								 ---------------------
    							 
    When program is launched, the player player must enter an _username_(which he can always use for future connections if he wishes to continue at the stage where he stopped during his last connection); select an avatar choose to _start_ or to _continue_ game.  
    When the game is launched, the player must do everything possible to keep his life bar above zero until he manages to eliminate the final boss monster of the stage.  
    To inflict damages to his enemies, the player can attack them with a sword by pressing the **SPACE KEY** on his keyboard or launch projectiles by simultaneously pressing **SPACE KEY** and **X KEY**.  
    To move player, use **direction keys** (alternatives: **A**,**W** and **D keys**)
    Sometimes, bonus can appear in the game surface, the player must take them to be immunised against monsters attacks or to increase his life bar.  
    
    
    
    								   -------------------
								  | ## Monsters Types |
								   -------------------
    
* Simples monsters: Zombies that inflict minor damages to the player if they touch him
* Kamikazes birds: Birds that attack in the air and which explode by touching the player (inflicting him damages) or his projectiles
* Main monster: It's the final boss monster of a stage


    

