			    ================================================================
			    ================================================================
                                                    # MONSTERS - KILLER - GAME
                                  =================================================================
                                  =================================================================


                                                ## Description - Fonctionnement


    Ce jeu consiste en une quete ou il faut eliminer tous les monstres presents sur son passage. 
    Au lancement du jeu, le joueur est invite a entrer un nom et selectionner un avatar avant de lancer la partie. Lorsque le joueur
quitte le jeu, son nom, son niveau, ainsi que son score sont sauvegardes; et a sa prochaine connexion, s'il entre le meme nom, il devra cliquer sur continuer pour reprendre le jeu depuis le niveau ou il s'etait arrete; sinon un message d'erreur lui sera renvoye
    Comme actions, le joueur peut attaquer et se deplacer a gauche (touche clavier 'fleche gauche' ou 'a'), a doite (touche clavier 
'fleche droite' ou 'd') et en haut (touche clavier 'fleche haut' ou 'w')
    Le joueur a deux possibilites d'attaques a sa disposition:
        - Il peut attaquer a l'epee (en appuiyant sur la touche 'ESPACE' du clavier)
        - Il peut lancer des projectiles si son nombre de tirs le permet (en appuiyant sur les touches 'ESPACE' et 'X' du clavier)
        Le joueur pert la partie si sa barre de vie est videe et gagne si c'est celle du boss-monter qui est videe
    Les monstres du jeu sont de differentes categories suivant les niveaux (beaucoup plus difficiles a eliminer).
    Le jeu comporte plusieurs etapes, et une partie est remportee lorsque le boss de fin est elimine, celui-ci est encore beaucoup
plus difficile a elimer que  ses sub-alternes, et a son apparution, des cometes se mettent a tomber du ciel. Le joueur devra les eviter dans la mesure du possible tout en continuant a affronter les monstres.
    Un monstre qui parvient a toucher un joueur inflige a celui-ci un certain nombre de degats selon que le joueur se laisse (gros
degats) faire ou qu'il riposte (degats minimes); une comete qui entre en collision avec le joueur lui inflige beaucoup plus de degats qu'une attaque de monstre.
    Si le joueur reste trop lompemts sur une plateforme, des oiseaux kamikases l'attaquent.
    Apres un certain temps dependemment du niveau, des bonus sont generes dans l'espace du joueur afin d'aider celui-ci dans 
l'accomplissement de sa quete, ceux-ci mettent un certain temps dans l'espace de jeu avant de disparaitre si le joueur ne s'en appare pas a temps. Deux categories de bonus:
    - Bonus Sante: Augmente la barre de vie du joueur (Represente par une tomate)
    - Bonus Bouclier: Rend le joueur invincible pendant un certain temps (Represente par une pomme)
